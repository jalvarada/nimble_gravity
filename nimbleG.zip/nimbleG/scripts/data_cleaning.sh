#!/bin/bash

#    ======================
#    == SCRIPT VARIABLES ==
#    ======================

# Path to working directory
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Scripts paths
CES_FILES_PATH="$DIR/ces_processing"
OTHER_FILES_PATH="$DIR/other"

# Data Paths
RAW_DATA_PATH="raw_data"
CES_BATCH_PATH="processed_data/ces_data_batches"
ATTRIBUTES_DATA_PATH="processed_data/attributes_data"


# Source the "time_it" function
source $OTHER_FILES_PATH/timing_function.sh

#    =========================================
#    == CES DATA BATCH PROCESSING FUNCTIONS ==
#    =========================================

clean_all_files() {
    for file in $CES_BATCH_PATH/*.csv; do
        $CES_FILES_PATH/clean.sh "$file"
    done
}

filter_all_files() {
    for file in $CES_BATCH_PATH/*.csv; do
        $CES_FILES_PATH/filter.sh "$file"
    done
}

#transform_all_files() {
#    for file in $CES_BATCH_PATH/*.csv; do
#        $CES_FILES_PATH/transform.sh "$file"
#    done
#}

count_rows_and_remove_empty() {
    total=0
    for file in $CES_BATCH_PATH/*.csv; do
        count=$(awk 'END { print NR }' "$file")
        let "total += $count"
        # If count is only 1 (just the header), delete the file
        if [ "$count" -le 1 ]; then
            rm "$file"
        fi
    done
    echo "Total rows across all files: $total"
}

start_time=$(date +%s)

# The real magic is about to begin my friend hehe
#echo "============================================"
#echo "Starting the CES data processing pipeline..."

#echo "--------------------------------------------"
#echo "1. Splitting the data..."
time_it "$CES_FILES_PATH/split.sh" "$RAW_DATA_PATH/ce.data.0.AllCESSeries"

#echo "--------------------------------------------"
#echo "2. Converting whitespace-separated files to CSV format..."
time_it clean_all_files

#echo "--------------------------------------------"
#echo "3. Filtering for data type codes 01, 06, and 10, exclude M13 period and remove footnote column..."
time_it filter_all_files

#echo "--------------------------------------------"
#echo "4. Counting rows and removing empty files..."
time_it count_rows_and_remove_empty

#echo "--------------------------------------------"
#echo "5. Adding supersector_id and data_type_code_id columns..."
#time_it transform_all_files

#echo "--------------------------------------------"
#echo "CES data processing pipeline completed."
#echo "============================================"

#end_time=$(date +%s)

#total_time=$(( (end_time - start_time) ))
#echo "Total execution time: $total_time seconds.\n \n"



#    ======================================
#    == ATTRIBUTES DATA BATCH PROCESSING ==
#    ======================================

#start_time=$(date +%s)

#echo "============================================"
#echo "Starting the ATTRIBUTES data processing pipeline..."

#echo "--------------------------------------------"
#echo "1. Copy files into the appropiate directory..."
cp "$RAW_DATA_PATH/ce.period" "$ATTRIBUTES_DATA_PATH/ce_period.csv"

#echo "--------------------------------------------"
#echo "2. Converting whitespace-separated files to CSV format..."
#time_it "$CES_FILES_PATH/clean.sh" "$ATTRIBUTES_DATA_PATH/ce_period.csv"
$CES_FILES_PATH/clean.sh "$ATTRIBUTES_DATA_PATH/ce_period.csv"

#echo "--------------------------------------------"
#echo "3. Remove header and last line from period data..."
awk 'NR == 1 { next } NR > 2 { print prev } { prev = $0 }' "$ATTRIBUTES_DATA_PATH/ce_period.csv" > "$ATTRIBUTES_DATA_PATH/ce_period.csv.tmp"
mv "$ATTRIBUTES_DATA_PATH/ce_period.csv.tmp" "$ATTRIBUTES_DATA_PATH/ce_period.csv"

#echo "--------------------------------------------"
#echo "ATTRIBUTES data processing pipeline completed."
#echo "============================================"

end_time=$(date +%s)

total_time=$(( (end_time - start_time) ))
echo "Total execution time: $total_time seconds.\n \n"