#!/bin/bash

# Variables
PASSWORD="$1"
CES_BATCH_PATH="processed_data/ces_data_batches"
ATTRIBUTES_DATA_PATH="processed_data/attributes_data"
HOST="localhost"
PORT="5432"
USER_DB="postgres"

export PGPASSWORD="$PASSWORD"

# Fill in ces table with batch data
for file in $CES_BATCH_PATH/batch_*.csv; do
    echo "\COPY api.ces FROM '$file' DELIMITER ',';" | psql -U "$USER_DB" -p "$PORT" -h "$HOST" -d nimbleg
done

echo "BATCH DATA DONE"

# Fill attributes
echo "\COPY api.period FROM '$ATTRIBUTES_DATA_PATH/ce_period.csv' DELIMITER ',';" | psql -U "$USER_DB" -p "$PORT" -h "$HOST" -d nimbleg

echo "ATTRIBUTE DATA DONE"

# Remove files to avoid any duplication -> not needed but just a reminder to generalize the solution
rm $CES_BATCH_PATH/*.csv
rm $ATTRIBUTES_DATA_PATH/*.csv


# Query for filling data used to answer:
# How was the evolution of women in goverment during time?
QUERY_women="
with merged_tables as (
    select  c.value
            ,concat_ws(' ', p.month, c.year)    as date
            ,substr(c.series_id, 4, 2)          as supersector 
            ,substr(c.series_id, 12, 2)         as data_type_code 
    from api.ces c

        left join api.period p
            on c.period = p.period
)

INSERT INTO api.women_in_government (date, valueInThousands)

select  date
        ,sum(value) as valueInThousands
from merged_tables
where supersector = '90' -- government
    and data_type_code = '10' -- women employee count
group by date
;
"

# Query for filling data used to answer:
# How was the evolution of the ratio "production employees / supervisory employees" during time? 
QUERY_ratio="
with merged_tables as (
    select  c.value
            ,concat_ws(' ', p.month, c.year)    as date
            ,substr(c.series_id, 12, 2)         as data_type_code 
    from api.ces c

        left join api.period p
            on c.period = p.period
)

,totals as (
    select  date
            ,sum(value) filter (where data_type_code = '01') as total_employees
            ,sum(value) filter (where data_type_code = '06') as production_employees
    from merged_tables
    where data_type_code in ('01','06')
    group by date
)

INSERT INTO api.employee_type_ratio (date, ratioProductionOverSupervisory)

select  date
        ,round(production_employees / (total_employees-production_employees), 6) as ratioProductionOverSupervisory
from totals
;
"

# Execute the query
psql -U "$USER_DB" -p "$PORT" -h "$HOST" -d nimbleg -c "$QUERY_women"
echo "WOMEN DATA DONE"
psql -U "$USER_DB" -p "$PORT" -h "$HOST" -d nimbleg -c "$QUERY_ratio"
echo "EMPLOYEE TYPE DATA DONE"

#psql -U "$USER_DB" -p "$PORT" -h "$HOST" -d nimbleg -c "COPY (select * from api.ces) TO STDOUT WITH CSV HEADER" > ces.csv
#psql -U "$USER_DB" -p "$PORT" -h "$HOST" -d nimbleg -c "COPY ($QUERY_ratio) TO STDOUT WITH CSV HEADER" > ratio.csv
