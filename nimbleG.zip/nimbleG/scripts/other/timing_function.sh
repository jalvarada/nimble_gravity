# timing_function.sh

time_it() {
    local command="$1"
    local args="$2"

    local start_time=$(date +%s)
    $command "$args"
    local end_time=$(date +%s)
    local elapsed_time=$((end_time - start_time))
    echo "Completed in ${elapsed_time} seconds."
}
