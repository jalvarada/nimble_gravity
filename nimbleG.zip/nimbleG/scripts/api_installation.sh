#!/bin/bash

# Download URL and installation paths
URL="https://github.com/PostgREST/postgrest/releases/download/v11.2.0/postgrest-v11.2.0-linux-static-x64.tar.xz"
INSTALL_PATH="/usr/local/bin"  # Standard path for user-installed binaries.

# Download PostgREST
echo "Downloading PostgREST..."
wget "$URL" -O postgrest.tar.xz

# Extract the archive
echo "Extracting the archive..."
tar -xf postgrest.tar.xz

# Move the binary to the installation path
echo "Installing PostgREST to $INSTALL_PATH..."
sudo mv postgrest "$INSTALL_PATH"

# Give it execute permissions
sudo chmod +x "$INSTALL_PATH/postgrest"

# Clean up
rm postgrest.tar.xz

# Install additional libraries
sudo apt-get install libpq-dev

echo "Installation completed! You can run PostgREST using the 'postgrest' command."

# postgrest ./connection_file.conf
# curl http://localhost:3000/ces\?series_id\=eq.CES0500000006\&year\=eq.1980