#!/bin/bash

input_file="$1"

awk -v maxsize=100000000 '   # set maxsize to the desired byte count, e.g., 100MB in this example
    NR == 1 {
        header = $0;
        headersize = length(header) + 1;  # +1 for the newline
        next;
    }
    {
        linesize = length($0) + 1;  # +1 for the newline
        cumulsize += linesize;
    }
    (cumulsize + headersize) > maxsize || NR == 2 {
        if (file) close(file);
        cumulsize = linesize;  # reset the cumulative size
        file = sprintf("processed_data/ces_data_batches/batch_%04d.csv", ++c);
        print header > file;
    }
    {print >> file}
' "$input_file"