#!/bin/bash

input_file="$1"
tmp_file="${input_file}.tmp"

# Convert Windows line endings to Unix if they exist
sed -i 's/\r$//' "$input_file"

# Extract supersector_id and data_type_code_id from series_id and add as new columns
awk -F, '{ 
    supersector_id = substr($1, 4, 2); 
    data_type_code_id = substr($1, length($1)-1);
    print $0 "," supersector_id "," data_type_code_id
  }' "$input_file" > "$tmp_file"

# Move the tmp file to overwrite the original
mv "$tmp_file" "$input_file"
