#!/bin/bash

input_file="$1"
tmp_file="${input_file}.tmp"

# Filter for rows where data type code in (01, 06, 10) 
# Exclude rows with "M13" in the third column, 
# Select only columns 1, 2, 3, and 4 (bye bye to footnotes column)
awk -F, 'substr($1, length($1)-1) ~ /^(01|06|10)$/ && $3 != "M13" {print $1 "," $2 "," $3 "," $4}' "$input_file" > "$tmp_file"


# Move the tmp file to overwrite the original
mv "$tmp_file" "$input_file"

