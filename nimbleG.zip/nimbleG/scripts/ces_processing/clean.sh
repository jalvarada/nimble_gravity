#!/bin/bash

input_file="$1"
tmp_file="${input_file}.tmp"

# Remove trailing and leading whitespace and replace sequences of whitespace with a comma
awk '{$1=$1; gsub(/[ \t]+/, ","); print}' "$input_file" > "$tmp_file"

# Move the tmp file to overwrite the original
mv "$tmp_file" "$input_file"

