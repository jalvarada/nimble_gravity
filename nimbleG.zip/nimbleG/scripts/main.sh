#!/bin/bash

#    ============================================
#      Set up the requiered directory structure
#    ============================================

# Top-level directories
mkdir -p processed_data
mkdir -p raw_data

# Sub-directories
mkdir -p processed_data/ces_data_batches
mkdir -p processed_data/attributes_data

#    ============================================
#      Variables
#    ============================================

# Set a password for postgres default user
echo "Please create your PostgreSQL password:"
read -s POSTGRES_PASSWORD

# Path to working directory
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

#    ==========================================
#      Set up from scratch the specified API   
#    ==========================================

echo "1. Data cleaning\n"
$DIR/data_cleaning.sh

echo "2. Setting up the database elements\n"
$DIR/database_setup.sh $POSTGRES_PASSWORD

echo "3. Fill the database\n"
$DIR/table_filling.sh $POSTGRES_PASSWORD

echo "4. Install API\n"
$DIR/api_installation.sh

echo " "
echo "Api ready to use! Yeeeah buddy!\n"
echo "To enable the api locally, run 'postgrest ./connection_file.conf' \n"
echo "Women in government for February 1990: curl curl http://localhost:3000/women_in_government?date=eq.February%201990"
echo "Employee type ratio: curl http://localhost:3000/employee_type_ratio?date=eq.May%2020003"
echo  "Women in Goverment for December thorugh the years: curl http://localhost:3000/women_in_government?date=like.December%"



# Dont forget these commands Josue (me talking to my future self)...
#chmod +x sh_files/*
#sudo service postgresql start
#./scripts/main.sh
#postgrest ./connection_file.conf
#curl http://localhost:3000/women_in_government
#curl http://localhost:3000/empoyee_type_ratio
#sudo service postgresql stop