#!/bin/bash

# https://postgrest.org/en/stable/tutorials/tut0.html
# Set PostgreSQL connection parameters
PASSWORD="$1"
HOST="localhost"
PORT="5432"
USER_DB="postgres"
DEFAULT_DB="postgres"

export PGPASSWORD="$PASSWORD"

# Set new password for postgres user
sudo -u "$USER_DB" psql -c "ALTER USER $USER_DB WITH PASSWORD '$PASSWORD';"

# Connect to the default database and create the nimbleg database
psql -U "$USER_DB" -p "$PORT" -h "$HOST" -d "$DEFAULT_DB" -c "CREATE DATABASE nimbleg;"

# Create the api schema in nimbleg database
psql -U "$USER_DB" -p "$PORT" -h "$HOST" -d nimbleg -c "CREATE SCHEMA api;"

# Create tables inside api schema in nimbleg database
psql -U "$USER_DB" -p "$PORT" -h "$HOST" -d nimbleg -c "
CREATE TABLE api.ces (
    series_id   TEXT,
    year        INT,
    period      TEXT,
    value       NUMERIC
);

CREATE TABLE api.period (
    period      TEXT,
    mm          TEXT,
    month       TEXT
);

CREATE TABLE api.women_in_government (
    date                TEXT,
    valueInThousands    NUMERIC
);

CREATE TABLE api.employee_type_ratio (
    date                            TEXT,
    ratioProductionOverSupervisory  NUMERIC
);
"

# Create the user roles and grant the permissions that postgrest suggest for api usage
sudo -u "$USER_DB" psql -d nimbleg -c "
    CREATE ROLE web_anon nologin;
    GRANT USAGE ON schema api to web_anon;
    GRANT SELECT ON api.women_in_government to web_anon;
    GRANT SELECT ON api.employee_type_ratio to web_anon;
    CREATE ROLE authenticator NOINHERIT LOGIN PASSWORD '$PASSWORD';
    GRANT web_anon TO authenticator;
"

# Write file requiered
echo "Creating POSTGREST connection file:"
echo "
db-uri = \"postgres://authenticator:$PASSWORD@$HOST:$PORT/nimbleg\"
db-schemas = \"api\"
db-anon-role = \"web_anon\"" > connection_file.conf


echo "Database setup completed!"


